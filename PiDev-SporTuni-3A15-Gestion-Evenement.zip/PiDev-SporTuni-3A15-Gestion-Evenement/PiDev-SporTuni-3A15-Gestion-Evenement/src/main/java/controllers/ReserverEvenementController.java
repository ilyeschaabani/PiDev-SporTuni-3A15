package controllers;
import entities.Evenement;
import entities.ReservationEv;
import javafx.scene.control.Alert;
import services.EmailService;
import services.ReservationService;

import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class ReserverEvenementController {

        @FXML
        private Label descriptionLabel;

        @FXML
        private Label descriptionLabel1;

        @FXML
        private Label descriptionLabel11;

        @FXML
        private Label descriptionLabel2;

        @FXML
        private Label disciplineLabel;

        @FXML
        private Label disciplineLabel1;

        @FXML
        private Label disciplineLabel11;

        @FXML
        private Label disciplineLabel2;

        @FXML
        private Label eventDatesLabel;

        @FXML
        private Label eventDatesLabel1;

        @FXML
        private Label eventDatesLabel11;

        @FXML
        private Label eventDatesLabel2;

        @FXML
        private Label eventNameLabel;

        @FXML
        private Label eventNameLabel1;

        @FXML
        private Label eventNameLabel11;

        @FXML
        private Label eventNameLabel2;

        @FXML
        private Label roomLabel;

        @FXML
        private Label roomLabel1;

        @FXML
        private Label roomLabel2;

        @FXML
        private Label roomLabel21;

        @FXML
        private Label roomLabel3;

        @FXML
        void handleReservation(ActionEvent event) {
            String nom_e = EventName.getText();

            String dateDebut = dateDebut .getText();
            String dateFin = dateFin.getText();

            Evenement evenement = new Evenement(nom_e, dateDebut, dateFin);

            // Vérifiez si le nombre maximum de participants est dépassé
            EmailService emailService;
            ReservationService reservationService=new ReservationService();
            if (reservationService.isMaxParticipantsReached(evenement)) {
                // Refuser la réservation
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Erreur de réservation");
                alert.setHeaderText(null);
                alert.setContentText("Le nombre maximum de participants pour cet événement est atteint. Réservation refusée.");
                alert.showAndWait();
                // Envoyer un e-mail de refus à l'utilisateur
                emailService.sendEmail("destinataire@example.com", "Refus de réservation", "Votre réservation pour l'événement " + nom_e + " a été refusée car le nombre maximum de participants est atteint.");
            } else {
                // Accepter la réservation

                ReservationEv reservation = new ReservationEv(evenement, "utilisateur@example.com");
                reservationService.addReservation(reservation);
                // Envoyer un e-mail de confirmation à l'utilisateur
                emailService.sendEmail("destinataire@example.com", "Confirmation de réservation", "Votre réservation pour l'événement " + nom_e + " a été acceptée.");
            }
        }
}



