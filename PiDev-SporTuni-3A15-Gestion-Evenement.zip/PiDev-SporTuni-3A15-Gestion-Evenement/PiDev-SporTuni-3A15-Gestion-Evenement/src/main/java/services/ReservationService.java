package services;

import entities.ReservationEv;
import services.EmailService;
import entities.ReservationEv;
import entities.Evenement;
public class ReservationService {

    private EmailService emailService;

    public ReservationService() {
        this.emailService = new EmailService();
    }

    public boolean accepterReservation(ReservationEv reservation) {

        String recipient = reservation.getUtilisateur().getEmail();
        String subject = "Acceptation de votre réservation";
        String body = "Votre réservation pour l'événement " + reservation.getIdR() + " a été acceptée.";
        emailService.sendEmail(recipient, subject, body);

        return true;
    }

    public boolean refuserReservation(ReservationEv reservation) {


        String recipient = reservation.getUtilisateur().getEmail();
        String subject = "Refus de votre réservation";
        String body = "Votre réservation pour l'événement " + reservation.getIdR() + " a été refusée.";
        emailService.sendEmail(recipient, subject, body);

        return true;
    }


}
